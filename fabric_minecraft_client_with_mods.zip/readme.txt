Hi Ho!
0. Zip File entpacken
1. Installiere den Fabric Loader (01 - fabric-installer-0.10.2.exe) - Minecraft Version 1.18
2. Testen ob er startet - Client wieder schließen.
3. Suche dein Minecraft Verzeichnis - Windows Suchleiste einfach %APPDATA% eingeben
4. C:\Users\User_Name\AppData\Roaming\ - Sollte dieser Pfad sein, mit deinem User_Name
5. Dort gibt es das Verzeichnis .minecraft - Dort findest Du alles was du brauchst für den Client.
6. Am Besten eine Verknüpfung auf den Desktop senden. 
7. Jetzt die Verzeichnisse mods und shaderpacks in das Verzeichnis .minecraft kopieren.
8. Client starten und checken, ob er eine Fehlermeldung zeigt - Hoffentlich nicht ;-)
9. Client schließen 
10. Iris Installer starten (02 - Iris-Installer-2.0.3.jar) - Falls bei Doppelklick nichts passiert
	vorher JVM runderladen und den Computer neu starten. 
	z.B von hier: https://www.chip.de/downloads/Java-Runtime-Environment-64-Bit_42224883.html
	Nach dem Neustart nochmal Installer starten. (Immer Minecraft 1.18 verwenden)
	Nach der Installation von Iris Client starten.
11. Iris optimiert deine Framerat und erlaubt shader.
12. Deine Mods Client und/oder Server Side sind im Punkt Mods im Hauptmenü zu finden.

Have fun!


